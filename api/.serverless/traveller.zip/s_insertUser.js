
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'bilima',
  applicationName: 'traveller',
  appUid: 'kKNXWlf0Nnj7YpWJd4',
  orgUid: '20b9f1e2-eb82-4c53-ba0e-1663a4d39411',
  deploymentUid: '270ccd89-5b7a-447b-8127-a689a54ba377',
  serviceName: 'traveller',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'traveller-dev-insertUser', timeout: 30 };

try {
  const userHandler = require('./src/lambda/user.js');
  module.exports.handler = serverlessSDK.handler(userHandler.insert, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}