const { find } = require("../services/locations");

module.exports = {
  find,
};
