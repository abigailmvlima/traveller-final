const connect = require("./connect");
const user = require("./user");
const locations = require("./locations");

module.exports = {
  connect,
  user,
  locations,
};
